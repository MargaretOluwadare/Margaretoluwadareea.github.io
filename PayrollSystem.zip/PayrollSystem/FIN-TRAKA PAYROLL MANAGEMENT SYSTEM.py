# Payroll Management System for FINTRAKA
# Install libraries and import modules
from tkinter import *
import random
import time
import datetime
from tkinter import messagebox
payroll = Tk()
payroll.geometry("1300x600")
payroll.resizable(0, 0)
payroll.title("FINTRAKA Payroll Management Systems")

# Exit
def exit():
    payroll.destroy()

# Reset
def reset():
    EmployeeName.set("")
    Address.set("")
    IDNo.set("")
    Gender.set("")
    CompanyName.set("")
    Location.set("")
    BasicSalary.set("")
    HousingAllowance.set("")
    TransportAllowance.set("")
    LunchAllowance.set("")
    OverTime.set("")
    GrossPay.set("")
    PAYE.set("")
    PAYEPeriod.set("")
    NSSF.set("")
    NSSFNumber.set("")
    ProvidentFunds.set("")
    OtherSavingSchemes.set("")
    TotalDeductions.set("")
    NetPay.set("")
    PayDate.set("")

# Pay Slip
def PayRef():
    PayDate.set(time.strftime("%d/%m/%Y"))
    refPay = random.randint(500, 1000)
    refPaid = ("PR" + str(refPay))
    Reference.set(refPaid)

    NSSFPay = random.randint(500, 1000)
    NSSFPaid = ("NSSF" + str(NSSFPay))
    NSSFNumber.set(NSSFPaid)

# Payment Period
def PayPeriod():
    t = datetime.datetime.now()
    PAYEPeriod.set(t.month)

# Basic Salary
def MonthlySalary():
    if BasicSalary.get() == "":
        BS = 0
    else:
        try:
            BS = float(BasicSalary.get())
        except ValueError:
            messagebox.showinfog("Error", "Wrong values!!! Use numbers.")
            BasicSalary.set("")

    if Location.get() == "":
        LW = 0
    else:
        try:
            LW = float(Location.get())
        except ValueError:
            messagebox.showinfo("Error", "Wrong values!!! Use numbers.")
            Location.set("")

    if HousingAllowance.get() == "":
        HA = 0
    else:
        try:
            HA = float(HousingAllowance.get())
        except ValueError:
            messagebox.showinfo("Error", "Wrong values!!! Use numbers.")
            HousingAllowance.set("")

    if TransportAllowance.get() == "":
        TA = 0
    else:
        try:
            TA = float(TransportAllowance.get())
        except ValueError:
            messagebox.showinfo("Error", "Wrong values!!! Use numbers.")
            TransportAlowance.set("")

    if LunchAllowance.get() == "":
        LA = 0
    else:
        try:
            LA = float(OverTime.get())
        except ValueError:
            messagebox.showinfo("Error", "Wrong values!!! Use numbers.")
            LunchAllowance.set("")

    if OverTime.get() == "":
        OT = 0
    else:
        try:
            OT = float(OverTime.get())
        except ValueError:
            messagebox.showinfo("Error", "Wrong values!!! Use numbers.")
            OverTime.set("")

    PTax = ((BS + HA + TA + LW + OT) * 0.3)
    PAYETax = "pln", str('%.2f' % ((PTax)))
    PAYE.set(PAYETax)

    P_NSSF = ((BS + HA + TA + LW + OT) * 0.02)
    PP_NSSF = "pln", str('%.2f' % ((P_NSSF)))
    NSSF.set(PP_NSSF)

    P_Provident = ((BS + HA + TA + LW + OT) * 0.02)
    PP_Provident = "pln", str('%.2f' % ((P_Provident)))
    ProvidentFund.set(PP_Provident)

    P_Saving = ((BS + HA + TA + LW + OT) * 0.01)
    PP_Saving = "pln", str('%.2f' % ((P_Saving)))
    OtherSavingSchemes.set(PP_NSSF)

    Deduct = PTax + P_NSSF + P_Provident + P_Saving
    Deduct_Payment = "pln", str('%.2f' % ((Deduct)))
    TotalDeductions.set(Deduct_Payment)

    NetPayAfter = ((BS + HA + TA + LW + OT) - Deduct)
    NetAfter = "pln", str('%.2f' % ((NetPayAfter)))
    NetPay.set(NetAfter)

    Gross_Pay = "pln", str('%.2f' % (BS + HA + TA + LW + OT))
    GrossPay.set(Gross_Pay)

EmployeeName = StringVar()
Address = StringVar()
IDNo = StringVar()
Gender = StringVar()
CompanyName = StringVar()
Location = StringVar()
BasicSalary = StringVar()
HousingAllowance = StringVar()
TransportAllowance = StringVar()
LunchAllowance = StringVar()
OverTime = StringVar()
GrossPay = StringVar()
PAYE = StringVar()
PAYEPeriod = StringVar()
NSSF = StringVar()
NSSFNumber = StringVar()
ProvidentFund = StringVar()
OtherSavingSchemes = StringVar()
TotalDeductions = StringVar()
NetPay = StringVar()
PayDate = StringVar()

textInput = StringVar()

Tops=Frame(payroll, width=1300, height=50, bd=15, relief="raise")
Tops.pack(side=TOP)

LF=Frame(payroll, width=650, height=300, bd=10, relief="raise")
LF.pack(side=LEFT)

RF=Frame(payroll, width=650, height=300, bd=10, relief="raise")
RF.pack(side=RIGHT)

lblTitle = Label(Tops, font=('arial', 30, 'bold'), text="FINTRAKA PAYROLL MANAGEMENT SYSTEM", fg="Steel blue", bd=10, anchor="w")
lblTitle.grid(row=0, column=0)

InsideLF=Frame(LF, width=500, height=100, bd=8, relief="raise")
InsideLF.pack(side=TOP)

InsideLFL=Frame(LF, width=250, height=100, bd=7, relief="raise")
InsideLFL.pack(side=LEFT)

InsideLFR=Frame(LF, width=250, height=100, bd=7, relief="raise")
InsideLFR.pack(side=RIGHT)

InsideRF=Frame(RF, width=500, height=100, bd=8, relief="raise")
InsideRF.pack(side=TOP)

InsideRFL=Frame(RF, width=250, height=100, bd=7, relief="raise")
InsideRFL.pack(side=LEFT)

InsideRFR=Frame(RF, width=250, height=100, bd=7, relief="raise")
InsideRFR.pack(side=RIGHT)

#==================Left Side
lblEmployeeName = Label(InsideLF, font=('arial', 12, 'bold'), text="Employee Name", fg="Steel blue", bd=10, anchor="w")
lblEmployeeName.grid(row=0, column=0)
txtEmployeeName = Entry(InsideLF, font=('arial', 12, 'bold'), bd=20, width=40, bg="powder blue", justify="left", textvariable = EmployeeName)
txtEmployeeName.grid(row=0, column=1)

lblIDNo = Label(InsideLF, font=('arial', 12, 'bold'), text="ID No", fg="Steel blue", bd=10, anchor="w")
lblIDNo.grid(row=2, column=0)
txtIDNo = Entry(InsideLF, font=('arial', 12, 'bold'), bd=20, width=40, bg="powder blue", justify="left", textvariable = IDNo)
txtIDNo.grid(row=2, column=1)

lblGender = Label(InsideLF, font=('arial', 12, 'bold'), text="Gender", fg="Steel blue", bd=10, anchor="w")
lblGender.grid(row=3, column=0)
txtGender = Entry(InsideLF, font=('arial', 12, 'bold'), bd=20, width=40, bg="powder blue", justify="left", textvariable = Gender)
txtGender.grid(row=3, column=1)

#==================Right Side
lblAddress = Label(InsideRF, font=('arial', 12, 'bold'), text="Address", fg="Steel blue", bd=10, anchor="w")
lblAddress.grid(row=0, column=0)
txtAddress = Entry(InsideRF, font=('arial', 12, 'bold'), bd=20, width=40, bg="powder blue", justify="left", textvariable = Address)
txtAddress.grid(row=0, column=1)

lblCompanyName = Label(InsideRF, font=('arial', 12, 'bold'), text="Company Name", fg="Steel blue", bd=10, anchor="w")
lblCompanyName.grid(row=1, column=0)
txtCompanyName = Entry(InsideRF, font=('arial', 12, 'bold'), bd=20, width=40, bg="powder blue", justify="left", textvariable = CompanyName)
txtCompanyName.grid(row=1, column=1)

lblLocation = Label(InsideRF, font=('arial', 12, 'bold'), text="Location", fg="Steel blue", bd=10, anchor="w")
lblLocation.grid(row=2, column=0)
txtLocation = Entry(InsideRF, font=('arial', 12, 'bold'), bd=20, width=40, bg="powder blue", justify="left", textvariable = Location)
txtLocation.grid(row=2, column=1)

#==================Left Left Side
lblBasicSalary = Label(InsideLFL, font=('arial', 12, 'bold'), text="Basic Salary", fg="Steel blue", bd=10, anchor="w")
lblBasicSalary.grid(row=0, column=0)
txtBasicSalary = Entry(InsideLFL, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="left", textvariable = BasicSalary)
txtBasicSalary.grid(row=0, column=1)

lblHousingAllowance = Label(InsideLFL, font=('arial', 12, 'bold'), text="Housing Allowance", fg="Steel blue", bd=10, anchor="w")
lblHousingAllowance.grid(row=1, column=0)
txtHousingAllowance = Entry(InsideLFL, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="left", textvariable = HousingAllowance)
txtHousingAllowance.grid(row=1, column=1)

lblTransportAllowance = Label(InsideLFL, font=('arial', 12, 'bold'), text="Transport Allowance", fg="Steel blue", bd=10, anchor="w")
lblTransportAllowance.grid(row=2, column=0)
txtTransportAllowance = Entry(InsideLFL, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="left", textvariable = TransportAllowance)
txtTransportAllowance.grid(row=2, column=1)

lblLunchAllowance = Label(InsideLFL, font=('arial', 12, 'bold'), text="Lunch Allowance", fg="Steel blue", bd=10, anchor="w")
lblLunchAllowance.grid(row=3, column=0)
txtLunchAllowance = Entry(InsideLFL, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="left", textvariable = LunchAllowance)
txtLunchAllowance.grid(row=3, column=1)

lblOverTime = Label(InsideLFL, font=('arial', 12, 'bold'), text="Over Time", fg="Steel blue", bd=10, anchor="w")
lblOverTime.grid(row=4, column=0)
txtOverTime = Entry(InsideLFL, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="right", textvariable = OverTime)
txtOverTime.grid(row=4, column=1)

#==================Left Right Side
lblPAYE = Label(InsideLFR, font=('arial', 12, 'bold'), text="PAYE", fg="Steel blue", bd=10, anchor="w")
lblPAYE.grid(row=0, column=0)
lblPAYE = Entry(InsideLFR, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="right", textvariable = PAYE)
lblPAYE.grid(row=0, column=1)

lblPAYEPeriod = Label(InsideLFR, font=('arial', 12, 'bold'), text="PAYE Period", fg="Steel blue", bd=10, anchor="w")
lblPAYEPeriod.grid(row=1, column=0)
lblPAYEPeriod = Entry(InsideLFR, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="right", textvariable = PAYEPeriod)
lblPAYEPeriod.grid(row=1, column=1)

lblNSSF = Label(InsideLFR, font=('arial', 12, 'bold'), text="NSSF", fg="Steel blue", bd=10, anchor="w")
lblNSSF.grid(row=2, column=0)
lblNSSF = Entry(InsideLFR, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="right", textvariable = NSSF)
lblNSSF.grid(row=2, column=1)

lblNSSFNumber = Label(InsideLFR, font=('arial', 12, 'bold'), text="NSSFNumber", fg="Steel blue", bd=10, anchor="w")
lblNSSFNumber.grid(row=3, column=0)
lblNSSFNumber = Entry(InsideLFR, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="right", textvariable = NSSFNumber)
lblNSSFNumber.grid(row=3, column=1)

lblOtherSavingSchemes = Label(InsideLFR, font=('arial', 12, 'bold'), text="Saving Scheme", fg="Steel blue", bd=10, anchor="w")
lblOtherSavingSchemes.grid(row=5, column=0)
lblOtherSavingSchemes = Entry(InsideLFR, font=('arial', 12, 'bold'), bd=12, width=15, bg="powder blue", justify="right", textvariable = OtherSavingSchemes)
lblOtherSavingSchemes.grid(row=5, column=1)

#----------------------------
lblProvidentFund = Label(InsideRFL, font=('arial', 12, 'bold'), text="Provident", fg="Steel blue", bd=10, anchor="w")
lblProvidentFund.grid(row=0, column=0)
lblProvidentFund = Entry(InsideRFL, font=('arial', 12, 'bold'), bd=11, width=15, bg="powder blue", justify="right", textvariable = ProvidentFund)
lblProvidentFund.grid(row=0, column=1)

lblGrossPay = Label(InsideRFL, font=('arial', 12, 'bold'), text="Gross Pay", fg="Steel blue", bd=10, anchor="w")
lblGrossPay.grid(row=1, column=0)
lblGrossPay = Entry(InsideRFL, font=('arial', 12, 'bold'), bd=11, width=15, bg="powder blue", justify="right", textvariable = GrossPay)
lblGrossPay.grid(row=1, column=1)

lblTotalDeductions = Label(InsideRFL, font=('arial', 12, 'bold'), text="Deductions", fg="Steel blue", bd=10, anchor="w")
lblTotalDeductions.grid(row=2, column=0)
txtTotalDeductions = Entry(InsideRFL, font=('arial', 12, 'bold'), bd=11, width=15, bg="powder blue", justify="right", textvariable = TotalDeductions)
txtTotalDeductions.grid(row=2, column=1)

lblNetPay = Label(InsideRFL, font=('arial', 12, 'bold'), text="Net Pay", fg="Steel blue", bd=10, anchor="w")
lblNetPay.grid(row=3, column=0)
lblNetPay = Entry(InsideRFL, font=('arial', 12, 'bold'), bd=11, width=15, bg="powder blue", justify="right", textvariable = NetPay)
lblNetPay.grid(row=3, column=1)

lblPayDate = Label(InsideRFL, font=('arial', 12, 'bold'), text="Pay Date", fg="Steel blue", bd=10, anchor="w")
lblPayDate.grid(row=4, column=0)
txtPayDate = Entry(InsideRFL, font=('arial', 12, 'bold'), bd=11, width=15, bg="powder blue", justify="left", textvariable = PayDate)
txtPayDate.grid(row=4, column=1)

#----------------------
btnSalaryPayment = Button(InsideRFR, padx=8, pady=8, fg="black", font=('arial', 12, 'bold'), width=14,
                        text="Salary Paymant", bg="sky blue", command=MonthlySalary).grid(row=0, column=0)

btnReset = Button(InsideRFR, padx=8, pady=8, fg="black", font=('arial', 12, 'bold'), width=14,
                        text="Reset System", bg="sky blue", command=reset).grid(row=1, column=0)

btnPayRef = Button(InsideRFR, padx=8, pady=8, fg="black", font=('arial', 12, 'bold'), width=14,
                        text="Pay Reference", bg="sky blue", command=PayRef).grid(row=2, column=0)

btnPayCode = Button(InsideRFR, padx=8, pady=8, fg="black", font=('arial', 12, 'bold'), width=14,
                        text="Pay Code", bg="sky blue", command=PayPeriod).grid(row=3, column=0)

btnExit = Button(InsideRFR, padx=8, pady=8, fg="black", font=('arial', 12, 'bold'), width=14,
                        text="Exit", bg="sky blue", command=exit).grid(row=4, column=0)

payroll.mainloop()
