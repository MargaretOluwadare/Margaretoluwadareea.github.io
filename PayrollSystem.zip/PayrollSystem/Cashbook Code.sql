CREATE TABLE transactions (
    id INT PRIMARY KEY,
    date DATE NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    type ENUM('income', 'expense') NOT NULL
);

CREATE TABLE account_balances (
    acid INT PRIMARY KEY,
    date DATE NOT NULL,
    balance DECIMAL(10, 2) NOT NULL
);
/*
-- Insert sample transactions
INSERT INTO transactions (id, date, description, amount, type)
VALUES (1, '2023-02-15', 'Sale of product A', 1000.00, 'income'),
       (2, '2023-02-16', 'Payment to supplier B', 500.00, 'expense'),
       (3, '2023-02-17', 'Sale of product C', 800.00, 'income');

-- Insert initial account balance
INSERT INTO account_balances (id, date, balance)
VALUES (1, '2023-02-15', 1000.00);

-- Calculate current balance
INSERT INTO account_balances (id, date, balance)
SELECT (SELECT MAX(id) FROM account_balances) + 1, 
       t.date, 
       (SELECT balance FROM account_balances WHERE date = (SELECT MAX(date) FROM account_balances)) 
       + CASE 
         WHEN t.type = 'income' THEN t.amount 
         WHEN t.type = 'expense' THEN -t.amount 
         ELSE 0 
         END 
*/
FROM transactions t
WHERE t.date > (SELECT MAX(date) FROM account_balances);

-- Generate income report
SELECT SUM(amount) as total_income
FROM transactions
WHERE type = 'income';

-- Generate expense report
SELECT SUM(amount) as total_expense
FROM transactions
WHERE type = 'expense';

-- Get current balance
SELECT balance
FROM account_balances
WHERE date = (SELECT MAX(date) FROM account_balances);
